/**
 * 家音英语 - 主应用逻辑
 * 负责页面导航、交互和整体应用状态管理
 */

const app = {
    // 当前状态
    currentPage: 'home',
    currentCard: null,
    currentAudio: null,
    longPressTimer: null,
    longPressDuration: 500, // 长按判定时间

    // 初始化
    init() {
        this.bindEvents();
        this.renderCards();
        this.renderHistory();
        this.updateStats();
        
        // 检查分享参数
        this.checkShareEntry();
        
        console.log('🎙️ 家音英语 HomeVoice English 已启动');
    },

    // 绑定事件
    bindEvents() {
        // 导航标签切换
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const page = e.currentTarget.dataset.page;
                this.navigate(page);
            });
        });

        // 录音按钮事件
        const recordBtn = document.getElementById('record-btn');
        if (recordBtn) {
            // 触摸设备
            recordBtn.addEventListener('touchstart', (e) => {
                e.preventDefault();
                this.startLongPress();
            });
            recordBtn.addEventListener('touchend', (e) => {
                e.preventDefault();
                this.endLongPress();
            });
            recordBtn.addEventListener('touchcancel', () => {
                this.cancelLongPress();
            });

            // 鼠标设备（桌面测试）
            recordBtn.addEventListener('mousedown', () => {
                this.startLongPress();
            });
            recordBtn.addEventListener('mouseup', () => {
                this.endLongPress();
            });
            recordBtn.addEventListener('mouseleave', () => {
                this.cancelLongPress();
            });
        }

        // 分享按钮
        const shareWechat = document.getElementById('share-wechat');
        if (shareWechat) {
            shareWechat.addEventListener('click', () => {
                this.handleShare('wechat');
            });
        }

        const shareCopy = document.getElementById('share-copy');
        if (shareCopy) {
            shareCopy.addEventListener('click', () => {
                this.handleShare('copy');
            });
        }

        // 发送按钮
        const sendBtn = document.getElementById('send-package');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => {
                this.sendPackage();
            });
        }

        // 设置开关
        const dailyReminder = document.getElementById('daily-reminder');
        if (dailyReminder) {
            dailyReminder.addEventListener('change', (e) => {
                localStorage.setItem('daily_reminder', e.target.checked);
                this.showToast(e.target.checked ? '已开启每日提醒' : '已关闭每日提醒');
            });
            
            // 加载设置
            dailyReminder.checked = localStorage.getItem('daily_reminder') !== 'false';
        }

        const soundEffect = document.getElementById('sound-effect');
        if (soundEffect) {
            soundEffect.addEventListener('change', (e) => {
                localStorage.setItem('sound_effect', e.target.checked);
                this.showToast(e.target.checked ? '已开启音效' : '已关闭音效');
            });
            
            // 加载设置
            soundEffect.checked = localStorage.getItem('sound_effect') !== 'false';
        }
    },

    // 页面导航
    navigate(page) {
        // 隐藏所有页面
        document.querySelectorAll('.page').forEach(p => {
            p.classList.remove('active');
        });

        // 显示目标页面
        const targetPage = document.getElementById(`${page}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
        }

        // 更新导航状态
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.page === page);
        });

        this.currentPage = page;

        // 页面特定逻辑
        if (page === 'history') {
            this.renderHistory();
        } else if (page === 'profile') {
            this.updateStats();
        }

        // 滚动到顶部
        window.scrollTo(0, 0);
    },

    // 渲染今日卡片
    renderCards() {
        const container = document.getElementById('cards-container');
        if (!container) return;

        const todayCards = Cards.getTodayCards();
        
        if (todayCards.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <span class="empty-icon">📚</span>
                    <p>今日卡片加载中...</p>
                </div>
            `;
            return;
        }

        container.innerHTML = todayCards.map((card, index) => `
            <div class="card ${index === 0 ? 'scene' : ''}" data-card-id="${card.id}">
                <div class="card-header">
                    <span class="card-scene">${card.sceneIcon} ${card.scene}</span>
                    <span class="card-favorite ${Cards.isFavorite(card.id) ? 'active' : ''}" data-card-id="${card.id}">
                        ${Cards.isFavorite(card.id) ? '⭐' : '☆'}
                    </span>
                </div>
                <h3 class="card-word">${card.word}</h3>
                <p class="card-translation">${card.translation}</p>
                <div class="card-example">
                    <p class="card-example-label">示例对话</p>
                    <p class="card-example-text">${card.example.en}</p>
                    <p class="card-example-text" style="color: #9CA3AF; margin-top: 4px;">${card.example.zh}</p>
                </div>
                <div class="card-hint">
                    <span class="card-hint-icon">💡</span>
                    <span>${card.aiScript}</span>
                </div>
            </div>
        `).join('');

        // 绑定卡片点击事件
        container.querySelectorAll('.card').forEach(cardEl => {
            cardEl.addEventListener('click', (e) => {
                // 如果点击的是收藏按钮，不进入录音页
                if (e.target.closest('.card-favorite')) {
                    return;
                }
                
                const cardId = parseInt(cardEl.dataset.cardId);
                this.openRecordPage(cardId);
            });
        });

        // 绑定收藏按钮事件
        container.querySelectorAll('.card-favorite').forEach(favBtn => {
            favBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const cardId = parseInt(favBtn.dataset.cardId);
                const isFav = Cards.toggleFavorite(cardId);
                favBtn.innerHTML = isFav ? '⭐' : '☆';
                favBtn.classList.toggle('active', isFav);
                
                this.showToast(isFav ? '已添加收藏' : '已取消收藏');
            });
        });
    },

    // 打开录音页面
    openRecordPage(cardId) {
        const card = Cards.getCardById(cardId);
        if (!card) return;

        this.currentCard = card;
        this.currentAudio = null;

        // 更新页面内容
        document.getElementById('record-scene').textContent = `${card.sceneIcon} ${card.scene}`;
        document.getElementById('record-word').textContent = card.word;
        document.getElementById('record-translation').textContent = card.translation;
        document.getElementById('ai-script').textContent = card.aiScript;

        // 重置录音状态
        document.getElementById('record-timer').textContent = '00:00';
        document.querySelector('.status-dot')?.classList.remove('recording');
        document.querySelector('.status-text')?.textContent = '按住说话';
        
        // 重置波形
        Recorder.drawIdleWaveform();

        // 导航到录音页
        this.navigate('record');
    },

    // 开始长按
    startLongPress() {
        const recordBtn = document.getElementById('record-btn');
        if (!recordBtn) return;

        recordBtn.classList.add('recording');

        this.longPressTimer = setTimeout(async () => {
            // 长按达到阈值，开始录音
            const success = await Recorder.start();
            if (success) {
                recordBtn.querySelector('.record-icon').textContent = '🔴';
                recordBtn.querySelector('.record-label').textContent = '松开结束';
            } else {
                this.cancelLongPress();
            }
        }, this.longPressDuration);
    },

    // 结束长按
    async endLongPress() {
        clearTimeout(this.longPressTimer);
        
        const recordBtn = document.getElementById('record-btn');
        if (!recordBtn) return;

        if (Recorder.isRecording) {
            // 正在录音，停止录音
            const audioBlob = await Recorder.stop();
            recordBtn.classList.remove('recording');
            recordBtn.querySelector('.record-icon').textContent = '🎙️';
            recordBtn.querySelector('.record-label').textContent = '长按录音';
            
            if (audioBlob) {
                this.currentAudio = audioBlob;
                this.openPreviewPage();
            }
        } else {
            recordBtn.classList.remove('recording');
        }
    },

    // 取消长按
    cancelLongPress() {
        clearTimeout(this.longPressTimer);
        
        const recordBtn = document.getElementById('record-btn');
        if (recordBtn) {
            recordBtn.classList.remove('recording');
            if (!Recorder.isRecording) {
                recordBtn.querySelector('.record-icon').textContent = '🎙️';
                recordBtn.querySelector('.record-label').textContent = '长按录音';
            }
        }

        if (Recorder.isRecording) {
            Recorder.stop();
        }
    },

    // 打开预览页面
    openPreviewPage() {
        if (!this.currentCard || !this.currentAudio) return;

        const shareData = Share.generateShareData(
            this.currentCard,
            Recorder.blobToUrl(this.currentAudio)
        );

        // 更新预览内容
        document.getElementById('preview-scene').textContent = 
            `${this.currentCard.sceneIcon} ${this.currentCard.scene}`;
        document.getElementById('preview-word').textContent = this.currentCard.word;
        document.getElementById('preview-translation').textContent = this.currentCard.translation;

        // 设置音频
        const audioEl = document.getElementById('preview-audio');
        if (audioEl) {
            audioEl.src = Recorder.blobToUrl(this.currentAudio);
            audioEl.addEventListener('loadedmetadata', () => {
                const duration = Recorder.formatDuration(Math.floor(audioEl.duration));
                document.getElementById('audio-duration').textContent = duration;
            });
        }

        // 存储分享数据
        this.currentShareData = shareData;

        // 导航到预览页
        this.navigate('preview');
    },

    // 处理分享
    async handleShare(type) {
        if (!this.currentShareData) return;

        if (type === 'wechat') {
            const success = await Share.shareToWechat(this.currentShareData);
            if (success) {
                this.showToast('分享成功');
            }
        } else if (type === 'copy') {
            await Share.copyLink(this.currentShareData);
            this.showToast('链接已复制');
        }
    },

    // 发送声音包裹
    async sendPackage() {
        if (!this.currentCard || !this.currentAudio) return;

        // 保存到历史记录
        Cards.addToHistory(this.currentCard.id, this.currentAudio);

        // 更新统计
        this.updateStats();

        // 显示成功提示
        this.showToast('✨ 声音包裹已发送！', 'success');

        // 延迟后返回首页
        setTimeout(() => {
            this.navigate('home');
            this.renderCards(); // 重新渲染卡片
        }, 1500);
    },

    // 渲染历史记录
    async renderHistory() {
        const listEl = document.getElementById('history-list');
        const emptyEl = document.getElementById('history-empty');
        
        if (!listEl || !emptyEl) return;

        const history = Cards.getHistory();

        if (history.length === 0) {
            listEl.style.display = 'none';
            emptyEl.style.display = 'block';
            return;
        }

        listEl.style.display = 'flex';
        emptyEl.style.display = 'none';

        listEl.innerHTML = await Promise.all(history.map(async (record, index) => {
            const audioUrl = await Cards.getAudioData(record.id)
                .then(blob => blob ? Recorder.blobToUrl(blob) : null)
                .catch(() => null);

            return `
                <div class="history-item" data-record-id="${record.id}">
                    <div class="history-icon">${record.card.sceneIcon}</div>
                    <div class="history-content">
                        <p class="history-word">${record.card.word}</p>
                        <p class="history-scene">${record.card.scene}</p>
                    </div>
                    <div class="history-date">${record.date}</div>
                </div>
            `;
        })).then(items => items.join(''));

        // 绑定点击事件
        listEl.querySelectorAll('.history-item').forEach(item => {
            item.addEventListener('click', async () => {
                const recordId = parseInt(item.dataset.recordId);
                const record = history.find(h => h.id === recordId);
                
                if (record) {
                    const audioBlob = await Cards.getAudioData(recordId);
                    if (audioBlob) {
                        this.currentCard = record.card;
                        this.currentAudio = audioBlob;
                        this.openPreviewPage();
                    }
                }
            });
        });
    },

    // 更新统计信息
    updateStats() {
        const stats = Cards.getStats();
        
        const totalEl = document.getElementById('stat-total');
        const weekEl = document.getElementById('stat-week');
        const streakEl = document.getElementById('stat-streak');

        if (totalEl) totalEl.textContent = stats.total;
        if (weekEl) weekEl.textContent = stats.week;
        if (streakEl) streakEl.textContent = stats.streak;
    },

    // 检查分享入口
    checkShareEntry() {
        const shareInfo = Share.checkShareParams();
        if (shareInfo.isShared) {
            // 从分享链接进入，可以显示特殊欢迎
            console.log('欢迎来自分享的朋友！');
        }
    },

    // 显示 Toast 提示
    showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        if (!toast) return;

        const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
        
        toast.querySelector('.toast-icon').textContent = icon;
        toast.querySelector('.toast-message').textContent = message;
        
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 2000);
    }
};

// 应用启动
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
