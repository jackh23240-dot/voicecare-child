# 🏠 HomeVoice English - 家音英语（子女端）

一个温暖的英语学习 Web 应用，让子女通过录音教父母学英语，将学习变成情感连接的载体。

## ✨ 核心特性

### 📱 每日灵感卡片
- 每天推送 3 个场景化单词（过海关、超市买菜、问路等）
- 精美卡片设计，包含单词、释义、例句、图片
- Instagram 信息流风格

### 🎤 长按录音
- 长按录音按钮录制发音
- 实时声波动画可视化
- 支持预览和重录

### 💡 AI 智能脚本
- 提供温馨的录音提示
- 例如："妈，今天教你'Passport'，就是护照的意思"
- 降低子女心理负担

### 🎁 声音包裹
- 将录制的单词打包成精美"包裹"
- 一键发送到微信
- 生成温馨分享卡片

### 📋 发送记录
- 查看历史发送记录
- 本地存储（localStorage）
- 随时回顾学习历程

## 🚀 快速开始

### 方法 1：直接打开
直接在浏览器中打开 `index.html` 文件即可使用。

### 方法 2：本地服务器
```bash
# 使用 Python
cd homevoice-parent
python3 -m http.server 8000

# 使用 Node.js
npx serve .

# 然后在浏览器访问 http://localhost:8000
```

### 方法 3：部署到 GitHub Pages
```bash
# 推送到 GitHub
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin git@github.com:yourusername/homevoice-parent.git
git push -u origin main

# 在 GitHub 设置中启用 GitHub Pages
```

## 📁 项目结构

```
homevoice-parent/
├── index.html          # 主页面
├── css/
│   └── style.css       # 样式文件
├── js/
│   └── app.js          # 主应用逻辑
└── README.md           # 说明文档
```

## 🎨 设计规范

基于 VoiceCare 方案设计：

| 维度 | 规范 |
|------|------|
| **主色调** | 活力蓝 #0057bd |
| **字体** | Inter / Noto Sans SC |
| **按钮高度** | 44px (标准触控) |
| **交互** | 列表 → 详情 流程 |
| **风格** | Instagram 编辑风格 |

### 设计原则
- **无边界原则**：不用 1px 实线分隔，用背景色变化
- **玻璃拟态**：20-30px 模糊背板，温暖通透
- **编辑式排版**：非对称布局 + 呼吸感留白
- **色调分层**：用材质堆叠创造深度

## 🎯 使用流程

### 1. 打开应用
访问页面，看到今日的 3 个单词卡片

### 2. 录制发音
- 点击卡片上的"录制发音"按钮
- **长按**录音按钮开始录音
- 对着麦克风读出单词和例句
- **松开**结束录音

### 3. 预览包裹
- 点击底部"发送到微信"按钮
- 预览已录制的单词
- 可以播放试听

### 4. 发送分享
- 点击"确认发送"
- 生成微信分享卡片
- 复制链接或截图发送给父母

## 📖 单词示例

### 今日场景：过海关 · At Customs

| 单词 | 音标 | 释义 | 例句 |
|------|------|------|------|
| Passport | /ˈpɑːspɔːt/ | 护照 | Don't forget your passport! |
| Customs | /ˈkʌstəmz/ | 海关 | We need to go through customs. |
| Visa | /ˈviːzə/ | 签证 | Do I need a visa? |

## 🔧 技术实现

- **HTML5**：语义化结构
- **CSS3**：Tailwind CSS + 自定义样式
- **JavaScript**：原生 ES6+
- **MediaRecorder API**：录音功能
- **SpeechSynthesis API**：TTS 发音
- **localStorage**：本地数据存储

## 🌐 浏览器兼容性

| 浏览器 | 支持情况 |
|--------|----------|
| Chrome | ✅ 完全支持 |
| Firefox | ✅ 完全支持 |
| Safari | ✅ 完全支持 |
| Edge | ✅ 完全支持 |
| 手机浏览器 | ✅ 完全支持 |

### 录音功能要求
- 需要 HTTPS 或 localhost 环境
- 需要麦克风权限
- Chrome/Edge 支持最佳

## 📱 移动端优化

- 响应式设计
- 触控友好的大按钮
- 适配各种屏幕尺寸
- 支持横竖屏切换

## 🎨 自定义

### 修改单词数据
编辑 `js/app.js` 中的 `dailyWords` 数组：

```javascript
const dailyWords = [
    {
        id: 1,
        word: 'YourWord',
        phonetic: '/音标/',
        meaning: '释义',
        scene: '场景',
        sceneEn: 'Scene Name',
        example: 'Example sentence.',
        exampleCn: '例句翻译',
        phrase: 'Related phrase',
        phraseCn: '短语翻译',
        image: '图片 URL',
        aiScript: 'AI 提示脚本'
    },
    // ... 更多单词
];
```

### 修改主题色
编辑 `index.html` 中的 Tailwind 配置：

```javascript
colors: {
    primary: '#你的主色',
    'primary-container': '#容器色',
    // ... 更多颜色
}
```

## 🚀 后续扩展

### 功能扩展
- [ ] 老人端应用
- [ ] 微信分享集成
- [ ] 云端数据同步
- [ ] 更多场景词库
- [ ] AI 纠音评分
- [ ] 学习统计报表

### 技术优化
- [ ] PWA 支持
- [ ] 离线使用
- [ ] 音频压缩
- [ ] 推送通知
- [ ] 多语言支持

## 📄 许可证

MIT License - 可自由使用和修改

## 💝 设计理念

> **"子女负责生产内容（录音 + 派单），老人负责情感消费（听声音 + 简单反馈）"**

将英语学习包装成**亲子之间的语音留言**，让学习变成情感连接的载体。

---

**让爱伴随学习，让亲情不断线** 🏠💙
